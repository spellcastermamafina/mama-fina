=== LC Lightbox Lite ===
Contributors: lcweb-projects
Donate link: https://charon.lcweb.it/8260d9df?ref=lc_lightbox_lite_adv
Tags: lightbox, gallery, fullscreen, image viewer, photography
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Give your website a modern image viewer in just one click. Responsive, customizable and free.

== Description ==

**LC Lightbox Lite** lets you display your images in a modern, elegant and responsive lightbox with virtually no setup required.

**[Check the live demo and play with it &raquo;](https://lcweb.it/lc-lightbox-lite-wordpress-plugin/?utm_source=lcll)**

Simply activate the plugin and every linked image on your website will automatically open inside LC Lightbox. No shortcodes, no blocks and no manual configuration.

Designed to stay lightweight and work seamlessly with any WordPress theme, it offers a polished viewing experience with touch gestures, keyboard navigation, fullscreen mode, thumbnails and many customization options.

Whether you run a blog, a portfolio or a photography website, LC Lightbox Lite gives your visitors a beautiful way to browse your images.


== 🌟 Main Features ==

* **Automatic integration:** linked images across your website are detected and grouped automatically
* **Responsive design:** optimized for desktop, tablet and mobile devices
* **Touch gestures:** swipe navigation on smartphones and tablets
* **Keyboard navigation**
* **Multiple lightbox skins**
* **Fullscreen mode**
* **Thumbnail navigation**
* **Smooth opening and closing animations**
* **Customizable colors and layout**
* **Optional slideshow**
* **Optional download button**
* **Social sharing support**
* **Highly configurable settings**

Everything works automatically, without editing your posts or pages.


== ⚡ Install, Activate, Done ==

LC Lightbox Lite has been built around a simple idea:

Install it, activate it and start enjoying a modern image viewer immediately.

The plugin automatically enhances linked images throughout your website, while giving you full control over the lightbox appearance and behavior from a single settings page.

No shortcodes. No gallery builders. No extra work.
Integrates seamlessly with the Wordpress builder but alsi with Elementor, Divi and WPbakery!


== 📱 Designed for Every Device ==

Your visitors will enjoy a smooth browsing experience on every screen size.

Desktop users benefit from keyboard navigation, elegant animations and mouse drag interactions. While mobile users can browse images naturally using touch gestures, maybe through the automatic fullscreen mode.


== 🎨 Make It Yours ==

Easily customize every aspect of the lightbox:

* Choose among multiple skins
* Select opening and closing effects
* Change overlay color and opacity
* Adjust maximum size
* Configure captions position
* Enable or disable thumbnails
* Enable fullscreen
* Configure slideshow timing
* Show or hide navigation controls
* Enable image download
* Fine-tune animations

No coding required.


== 🚀 Need Complete Photo Galleries? ==

LC Lightbox Lite is designed to do one thing exceptionally well: displaying your linked images inside a beautiful lightbox.
If you're looking for a complete gallery management solution, **[Global Gallery](https://lcweb.it/global-gallery-wordpress-photogallery-plugin/?utm_source=lcll)** is the perfect next step.

Integrating an advanced version of the LC Lightbox engine, [Global Gallery](https://lcweb.it/global-gallery-wordpress-photogallery-plugin/?utm_source=lcll) lets you create professional photo galleries with features such as:

* Unlimited responsive galleries
* Masonry, justified and grid layouts
* Albums and collections
* Image filters
* Watermarks
* Image protection
* Cloud image sources
* Image sliders
* ...and much more.

Developed by LCweb, empowers thousands of premium websites sinc 2012.  Discover [Global Gallery](https://lcweb.it/global-gallery-wordpress-photogallery-plugin/?utm_source=lcll)!



== Installation ==

1. Upload `lc-lightbox-lite` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Open **LC Lightbox Lite** from the WordPress admin menu.
4. Enable the integration and customize the lightbox as you prefer.
5. That's it! Linked images throughout your website will automatically open inside LC Lightbox.


== Frequently Asked Questions ==

= Does it work automatically? =

Yes. Once activated, LC Lightbox Lite automatically detects linked images across your website.

= Do I need to edit my existing posts? =

No. Existing linked images will immediately start using the lightbox.

= Does it work on mobile devices? =

Absolutely. The lightbox is fully responsive and supports touch gestures, swipe navigation and fullscreen mode.

= Can I customize its appearance? =

Yes. You can choose different skins, animations, colors and many display options from the settings page.

= Can I disable thumbnails or fullscreen? =

Yes. Most lightbox features can be enabled or disabled individually.

= Is it compatible with my theme? =

The plugin is designed to work with virtually any WordPress theme and automatically targets standard linked images.

= I need advanced photo galleries =

LC Lightbox Lite focuses on displaying images inside a beautiful lightbox.

If you need to create professional galleries, albums, image collections, cloud integrations and many more advanced features, [Global Gallery](https://lcweb.it/global-gallery-wordpress-photogallery-plugin/?utm_source=lcll) is the recommended solution.


== Screenshots ==

1. Minimal skin + text over
2. Dark skin + text on side
3. Light skin + text under
4. Fullscreen mode
5. Available settings


== Changelog ==

= 1.0.0 =
* Initial release.


== Upgrade Notice ==

= 1.0.0 =

First public release.