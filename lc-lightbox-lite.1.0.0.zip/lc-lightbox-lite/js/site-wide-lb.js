(function($) {
    "use strict";
    
    // Jan 2024 - Google Drive blocks image preloading through JS - use the thumb trick
    window.gg_gdrive_img_url_trick = function(img_url) {
        if(img_url.indexOf('drive.google.com') === -1) {
            return img_url;   
        }
        
        const url_obj = new URL(img_url);
        if(url_obj.searchParams.get('id')) {
            img_url = 'https://drive.google.com/thumbnail?sz=w5000&id='+ url_obj.searchParams.get('id');
        }
        
        return img_url;
    };
    
    
    // fix for HTML inside attribute
	window.gg_lb_html_fix = function(str) {
		var txt = (typeof(str) == 'string') ? str.replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;') : '';
		return $.trim(txt);
	};
    
    
    // htrowing the lightbox
    window.gg_throw_lb = function(gall_obj, rel, clicked_index, no_deeplink) {
        if(!Object.keys(gall_obj).length) {
            return false;
        }
        ($('#lcll_lb_gall').length) ? $('#lcll_lb_gall').empty() : $('body').append(`<div id='lcll_lb_gall'></div>`);

        if(typeof(lcll_no_lb) != 'undefined') {
            return false;	
        }

        let sel_img = [];
        $.each(Object.keys(gall_obj), function(i, v) {	
            const obj = gall_obj[v];
            const o = {
                src				: obj.img,
                title			: obj.title,
                txt				: obj.descr,
                author			: obj.author,
                canonical_url	: false
            };
            sel_img.push(o);
        });

        let config = {...window.lcll_config};

        if(typeof window.lcll_config_filters !== 'undefined') {
            window.lcll_config_filters.forEach(fn => config = fn(config));
        }

        if(config.deeplink && typeof(no_deeplink) != 'undefined' && no_deeplink) {
            config.deeplink = false;   
        }
        const lcll_obj = lc_lightbox(sel_img, config);

        if(no_deeplink || typeof(lcll_prepare) == 'undefined' || !lcll_prepare) {
            lcl_open(lcll_obj, clicked_index);
        }
        else {
            if(typeof(lcll_nulling_prepare) != 'undefined') {
                clearTimeout(lcll_nulling_prepare);
            }
            lcll_nulling_prepare = setTimeout(function() {
                lcll_prepare = false;
            }, 150);
        }
    };
    
    
    
    //////////////////////////////////////////////////
    
    
    
    $(document).ready(function() {
        const IMG_EXT = /\.(jpe?g|png|gif|webp|svg)(\?.*)?$/i;

        /* selectors to exclude from lightbox targeting */
        const EXCLUDE_ZONES = [
            '#wpadminbar',
            '.gg_gallery_wrap',
            '.envira-gallery-wrap',
            '.ngg-gallery-container',
            '.mfp-content',
            '.et_pb_gallery_item', /* Divi gallery items (handled separately) */
            '.woocommerce-product-gallery' /* WooCommerce product gallery (handled separately) */
        ].join(', ');


        /* check if a href points to an image file */
        const isImageHref = function(href) {
            return IMG_EXT.test(href || '');
        };


        /* find all <a> candidates within a given scope, excluding already-processed and conflicting elements */
        const getCandidates = function(scope) {
            return scope.find('a:has(img)').addBack('a:has(img)').filter(function() {
                const href = $(this).attr('href') || '';

                if(
                    !isImageHref(href) ||
                    $(this).closest(EXCLUDE_ZONES).length ||
                    $(this).closest(`[data-elementor-open-lightbox='yes']`).length ||
                    $(this).is('[data-fancybox], [data-colorbox]') ||
                    $(this).closest('[data-fancybox], [data-colorbox]').length ||
                    $(this).data('lclb-assigned')
                ) {
                    return false;
                }

                return true;
            });
        };


        /* walk up the DOM (max 2 levels) to find a common parent containing 2+ image links, then assign a group name */
        const assignGroups = function(candidates) {
            let groupIndex = 0;

            candidates.each(function() {
                if($(this).data('lclb-assigned')) return;

                /* native Elementor slideshow group */
                const elSlideshow = $(this).attr('data-elementor-lightbox-slideshow');
                if(elSlideshow) {
                    $(this).attr('data-lclb-group', 'el-' + elSlideshow).data('lclb-assigned', true);
                    return;
                }

                let group   = null,
                    current = $(this).parent();

                for(let i = 0; i < 2; i++) {
                    if(!current.length || current.is('body')) break;

                    let imgLinks = current.find('> a').filter(function() {
                        return isImageHref($(this).attr('href') || '');
                    });

                    if(!imgLinks.length) {
                        imgLinks = current.find('> * > a').filter(function() {
                            return isImageHref($(this).attr('href') || '');
                        });
                    }

                    if(imgLinks.length >= 2) {
                        group = imgLinks;
                        break;
                    }

                    current = current.parent();
                }

                if(!group || group.length < 2) return;

                /* reuse existing group name on dynamic DOM additions */
                const existingGroup = group.filter('[data-lclb-group]').first().attr('data-lclb-group'),
                      gName         = existingGroup || 'lclb-group-' + (++groupIndex);

                group.each(function() {
                    if(!$(this).data('lclb-assigned')) {
                        $(this).attr('data-lclb-group', gName).data('lclb-assigned', true);
                    }
                });
            });
        };


        /* build the gall_obj expected by gg_throw_lb() from a set of <a> elements */
        const buildGallObj = function(links) {
            const gall_obj = {};

            links.each(function() {
                const href = $(this).attr('href') || '';
                if(!href || gall_obj[href]) return;

                const img = $(this).find('img').first(),

                      /* priority: elementor attr > link title (Divi/WPBakery) > img title > img alt */
                      title = $(this).attr('data-elementor-lightbox-title') || $(this).attr('title') || img.attr('title') || img.attr('alt') || '',
                      descr = '',

                      /* priority: explicit per-link override (e.g. WooCommerce data-large_image) > gdrive trick > raw href */
                      raw_url = $(this).data('lclb-img-url') || href,
                      img_url = (typeof window.gg_gdrive_img_url_trick === 'function')
                          ? window.gg_gdrive_img_url_trick(raw_url)
                          : raw_url;

                gall_obj[href] = {
                    img   : img_url,
                    title : (typeof gg_lb_html_fix === 'function') ? gg_lb_html_fix(title) : title,
                    descr : (typeof gg_lb_html_fix === 'function') ? gg_lb_html_fix(descr) : descr,
                    author: ''
                };
            });

            return gall_obj;
        };


        /* handle click on a candidate link: build gallery object and open via gg_throw_lb() */
        const handleClick = function(e) {
            e.preventDefault();

            if(typeof window.gg_throw_lb === 'undefined') return;

            const clicked     = $(this),
                  clickedHref = clicked.attr('href') || '',
                  group       = clicked.attr('data-lclb-group'),
                  groupLinks  = group ? $(`[data-lclb-group='`+ group +`']`) : clicked,
                  gall_obj    = buildGallObj(groupLinks);

            if(!Object.keys(gall_obj).length) return;

            let clicked_index = 0;
            Object.keys(gall_obj).forEach(function(url, i) {
                if(url === clickedHref) clicked_index = i;
            });

            const no_deeplink = (clicked.parents('.woocommerce-product-gallery__wrapper').length) ? true : false;
            window.gg_throw_lb(gall_obj, group || 'lclb-single', clicked_index, no_deeplink);
        };


        /* process a DOM scope: find candidates, assign groups, bind click handler */
        const processNodes = function(scope) {
            const candidates = getCandidates(scope);
            if(!candidates.length) return;

            assignGroups(candidates);
            candidates.on('click', handleClick);
        };


        let wcGroupIndex = 0;

        /* WooCommerce product gallery (PhotoSwipe): single trigger per gallery, opens the currently active slide */
        const processWcGallery = function(scope) {
            const galleries = scope.find('.woocommerce-product-gallery').addBack('.woocommerce-product-gallery');

            galleries.each(function() {
                const gallery = $(this),
                      links    = gallery.find('.woocommerce-product-gallery__image > a');

                if(!links.length) return;

                const gName = gallery.data('lclb-wc-gname') || 'wc-gall-' + (++wcGroupIndex);
                gallery.data('lclb-wc-gname', gName);

                links.attr('data-lclb-group', gName).each(function() {
                    $(this).data('lclb-assigned', true);
                });

                const trigger = gallery.find('.woocommerce-product-gallery__trigger');
                if(!trigger.length) return;

                trigger.data('lclb-assigned', true);

                trigger.get(0).addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    
                    /* detect the active slide: try common active-slide markers first, then :visible, then fall back to the first link */
                    let activeLink = gallery.find(
                        '.woocommerce-product-gallery__image.flex-active-slide > a, ' +
                        '.woocommerce-product-gallery__image.is-active > a, ' +
                        '.woocommerce-product-gallery__image[aria-hidden=false] > a'
                    ).first();

                    if(!activeLink.length) activeLink = links.filter(':visible').first();
                    if(!activeLink.length) activeLink = links.first();

                    handleClick.call(activeLink.get(0), e);
                }, true);
            });
        };


        /* initial run on full body */
        processNodes($(`body`));


        /* --- Elementor: intercept image widgets before its lightbox binds --- */
        const elementorImageHook = function(scope) {
            scope.find('a[data-elementor-open-lightbox]')
                .attr('data-elementor-open-lightbox', 'no');
            processNodes(scope);
        };

        const bindElementorHooks = function() {
            elementorFrontend.hooks.addAction('frontend/element_ready/image.default', elementorImageHook);
            elementorFrontend.hooks.addAction('frontend/element_ready/image-gallery.default', elementorImageHook);
        };

        if(typeof elementorFrontend !== 'undefined' && typeof elementorFrontend.hooks !== 'undefined') {
            /* Elementor already initialized (e.g. script loaded late / inline at page bottom) */
            bindElementorHooks();
        }
        else if(typeof elementorFrontend !== 'undefined') {
            /* Elementor present but not yet initialized: wait for its init event */
            window.addEventListener('elementor/frontend/init', bindElementorHooks);
        }


        /* --- Divi + WPBakery + WooCommerce: capture phase beats any jQuery bubble handler regardless of binding order --- */
        setTimeout(function() {

            /* Divi gallery module: group by .et_pb_gallery_items container */
            $('.et_pb_gallery_items').each(function(i) {
                const container = $(this),
                      gName     = 'divi-gall-' + i;

                container.find('.et_pb_gallery_image a').each(function() {
                    $(this)
                        .attr('data-lclb-group', gName)
                        .data('lclb-assigned', true);

                    this.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        handleClick.call(this, e);
                    }, true);
                });
            });

            /* Divi single image module: identified by .et_pb_lightbox_image on the <a> */
            $('.et_pb_lightbox_image').not('[data-lclb-assigned]').each(function() {
                $(this).data('lclb-assigned', true);

                this.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    handleClick.call(this, e);
                }, true);
            });

            /* WPBakery single image and gallery grid: group id encoded in data-lightbox attribute */
            /* removeAttr disables WPBakery lightbox2 (lazy init on click); capture as extra safety */
            $('[data-lightbox]').filter(function() {
                return isImageHref($(this).attr('href') || '');
            }).not('[data-lclb-assigned]').each(function() {
                const lbVal = $(this).attr('data-lightbox') || '',
                      gName = lbVal ? 'wpb-' + lbVal.replace(/\W+/g, '-') : null;

                if(gName) {
                    $(this).attr('data-lclb-group', gName);
                }

                $(this)
                    .removeAttr('data-lightbox')
                    .data('lclb-assigned', true);

                this.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    handleClick.call(this, e);
                }, true);
            });

            /* WooCommerce product gallery (PhotoSwipe) */
            processWcGallery($('body'));

        }, 0);


        /* watch for dynamically added nodes and process them in debounced batches */
        const pendingNodes = [];
        let observerTimer  = null;

        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                    if(node.nodeType === 1) pendingNodes.push(node);
                });
            });

            /* debounce: wait for DOM to settle before processing (handles rapid bulk insertions) */
            clearTimeout(observerTimer);
            observerTimer = setTimeout(function() {
                if(!pendingNodes.length) return;

                const nodes = pendingNodes.splice(0);
                nodes.forEach(function(node) {
                    processNodes($(node));
                    processWcGallery($(node));
                });
            }, 200);
        });

        observer.observe(document.body, {
            childList: true,
            subtree  : true
        });
    });
     
})(jQuery);