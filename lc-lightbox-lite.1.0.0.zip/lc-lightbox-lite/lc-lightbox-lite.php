<?php
/* 
Plugin Name: LC Lightbox Lite
Plugin URI: https://lcweb.it/
Description: The free and lightweight way to add a modern and responsive lightbox to your website images
Author: Luca Montanari (LCweb)
Author URI: https://lcweb.it
Version: 1.0.0
License: GPLv2 or later
Requires at least: 5.0
Requires PHP: 7.0
*/  


if(!defined('ABSPATH')) {exit;}


/////////////////////////////////////////////
/////// MAIN DEFINES ////////////////////////
/////////////////////////////////////////////

// plugin path
$wp_plugin_dir = substr(plugin_dir_path(__FILE__), 0, -1);
define('LCLL_DIR', $wp_plugin_dir);

// plugin url
$wp_plugin_url = substr(plugin_dir_url(__FILE__), 0, -1);
define('LCLL_URL', $wp_plugin_url);


// plugin version
define('LCLL_VER', '1.0.0');
define('LCLL_LB_VER', '2.2.0');




/////////////////////////////////////////////
/////// MULTILANGUAGE SUPPORT ///////////////
/////////////////////////////////////////////

function lcll_multilanguage() {
    $ml_key = 'lc-lightbox-lite';
    $basedir = LCLL_DIR;

    load_textdomain($ml_key, $basedir .'/languages/'. $ml_key .'-'. determine_locale() .'.mo');
}
add_action('plugins_loaded', 'lcll_multilanguage', 1);





/////////////////////////////////////////////
/////// MAIN SCRIPT & CSS INCLUDES //////////
/////////////////////////////////////////////


function lcll_admin_scripts() {
    global $current_screen;

    if(!is_object($current_screen) || $current_screen->base != 'toplevel_page_lcll_settings') {
        return;
    }

    wp_enqueue_script('jquery');

    // LC tools
    wp_enqueue_style('lcwp-lc-select',      LCLL_URL .'/js/lc-select/themes/lcwp_prefixed.css', 100, '1.3.0');
    wp_enqueue_script('lc-select',          LCLL_URL .'/js/lc-select/lc_select.min.js', 100, '1.3.0', true);
    wp_enqueue_script('lc-color-picker',    LCLL_URL .'/js/lc-color-picker/lc_color_picker.min.js', 200, '2.0.0', true);

    wp_enqueue_script('lc-wp-popup-message',LCLL_URL .'/js/lc-wp-popup-message/lc_wp_popup_message.min.js', 200, '1.2.1', true);
    wp_enqueue_script('lc-switch-v2',       LCLL_URL .'/js/lc-switch/lc_switch.min.js', 200, '2.0.4', true);
    wp_enqueue_script('lc-range-n-num',     LCLL_URL .'/js/lc-range-n-num/lc_range_n_num.min.js', 200, '1.0.1', true);


    wp_enqueue_style('lcll_admin', LCLL_URL .'/css/admin.css', 100, LCLL_VER);	
    wp_enqueue_style('lcll_settings', LCLL_URL .'/settings/settings_style.css', 999, LCLL_VER);	
    wp_enqueue_script('lcll_settings', LCLL_URL .'/settings/mandatory_js.js', 999, LCLL_VER, true);

    if(lcll_static::is_wp7()) {
        wp_enqueue_style('lcll-admin-wp7', LCLL_URL .'/css/wp7_admin.css', 1501, LCLL_VER);
    }
}
add_action('admin_enqueue_scripts', 'lcll_admin_scripts');




function lcll_front_scripts() {
    if(!get_option('lcll_site_wide_lb')) {
        return;   
    }

    // js
    wp_enqueue_script('jquery');
    lcll_lightboxes::enqueue_scripts();

    wp_enqueue_script('lcll-core', LCLL_URL .'/js/lc-lightbox/js/lc_lightbox.lite.min.js', array('jquery'), LCLL_LB_VER, true);
    wp_enqueue_script('lcll-swlb', LCLL_URL .'/js/site-wide-lb.min.js', array('jquery'), LCLL_VER, true);

    // css
    wp_enqueue_style('lcll-core', LCLL_URL .'/js/lc-lightbox/css/lc_lightbox.min.css', 90, LCLL_LB_VER);
    wp_enqueue_style('lcll-skin', LCLL_URL .'/js/lc-lightbox/skins/'. get_option('gg_lb_lcl_style', 'minimal') .'.css', 99, LCLL_LB_VER);
    wp_enqueue_style('lcll-oc', LCLL_URL .'/js/lc-lightbox/css/open_close_fx.css', 99, LCLL_VER);
}
add_action('wp_enqueue_scripts', 'lcll_front_scripts', 900);






/////////////////////////////////////////////
/////// MAIN INCLUDES ///////////////////////
/////////////////////////////////////////////

include_once(LCLL_DIR .'/classes/lcll_static.php');

include_once(LCLL_DIR .'/classes/lightboxes.php');

include_once(LCLL_DIR .'/admin_menu.php');