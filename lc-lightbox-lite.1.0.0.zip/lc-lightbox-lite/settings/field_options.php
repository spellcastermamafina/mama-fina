<?php 
if(!defined('ABSPATH')) {exit;}



// LC Lightbox - openClose effects list
function lcll_openclose_list() {
	return array(
		'lcl_fade_oc' 		=> esc_html__('Fade', 'lc-lightbox-lite'),
		'lcl_zoomin_oc' 	=> esc_html__('Zoom-in', 'lc-lightbox-lite'),
		'lcl_bottop_oc' 	=> esc_html__('Bottom to top', 'lc-lightbox-lite'),
		'lcl_bottop_v2_oc' 	=> esc_html__('Bottom to top v2', 'lc-lightbox-lite'),
		'lcl_rtl_oc' 		=> esc_html__('Right to left', 'lc-lightbox-lite'),
		'lcl_horiz_flip_oc' => esc_html__('Horizontal flip', 'lc-lightbox-lite'),
		'lcl_vert_flip_oc' 	=> esc_html__('Vertical flip', 'lc-lightbox-lite'),
		'' 					=> esc_html__('None (customizable through CSS)', 'lc-lightbox-lite'),
	);
}



// get the LC lightbox patterns list 
function lcll_patterns_list() {
	$patterns = array();
	$patterns_list = scandir(LCLL_DIR ."/js/lc-lightbox/img/patterns");
	 
	foreach($patterns_list as $pattern_name) {
		if($pattern_name != '.' && $pattern_name != '..') {
			$patterns[$pattern_name] = substr($pattern_name, 0, -4);
		}
	}
	return $patterns;	
}

