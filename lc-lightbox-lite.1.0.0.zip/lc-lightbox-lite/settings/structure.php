<?php 
if(!defined('ABSPATH')) {exit;}
include_once(LCLL_DIR . '/settings/field_options.php'); 


// LCLL-FILTER - manipulate settings tabs
$tabs = array(
	'main_opts' => esc_html__('Main Options', 'lc-lightbox-lite'),
    'want_more' => '🌟 '. esc_html__('Want more?', 'lc-lightbox-lite'),
);
$GLOBALS['lcll_settings_tabs'] = apply_filters('lcll_settings_tabs', $tabs);	


// STRUCTURE
/* tabs index => array( 
	'sect_id' => array(
		'sect_name'	=> name
		'fields'	=> array(
			...
		)
	)
   )
*/

$structure = array();




	
####################################
########### LIGHTBOX ###############
####################################		
$structure['main_opts'] = array(
		
	'main' => array(
		'sect_name'	=>  '&nbsp;',
		'fields' 	=> array(
			
            'lcll_site_wide_lb' => array(
				'label' => esc_html__('Enable lightbox integration?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, applies the LC Lightbox to any linked image on the whole website. Ideally this would display a unique lightbox for your website", 'lc-lightbox-lite') .'<br/>('. esc_html__("covers also WooCommerce, Elementor, Divi and WPbakery)", 'lc-lightbox-lite').')',
                'autoload' => true,
			),
		),
	),	
	
	
	'lb_opts' => array(
		'sect_name'	=> esc_html__('Lightbox Options', 'lc-lightbox-lite'),
		'fields' 	=> array(
			
			'lcll_lb_style' => array(
				'label' 	=> esc_html__("Style", 'lc-lightbox-lite'),
				'type'		=> 'select',
				'val' 		=> array(
					'minimal'	=> esc_html__('Minimal', 'lc-lightbox-lite'), 
					'light'		=> esc_html__('Light', 'lc-lightbox-lite'),
					'dark'		=> esc_html__('Dark', 'lc-lightbox-lite'), 
				),
				'note'		=> esc_html__('Select the lightbox skin', 'lc-lightbox-lite'),
                'autoload'  => true,
			),
			'lcll_lb_openclose' => array(
				'label' 	=> esc_html__("Open/close effect", 'lc-lightbox-lite'),
				'type'		=> 'select',
				'val' 		=> lcll_openclose_list(),
                'def'       => 'lcl_zoomin_oc',
                
				// translators: 1–4: <em> and </em> tags used around class names.
                'note' => sprintf( esc_html__('Select which opening/closing effect to use (for custom CSS, classes are %1$s.lcl_pre_show%2$s and %3$s.lcl_is_closing%4$s)', 'lc-lightbox-lite' ), '<em>', '</em>', '<em>', '</em>' ),
			),
			'lcll_lb_ol_color' => array(
				'label' 	=> esc_html__("Background color", 'lc-lightbox-lite'),
				'type'		=> 'color',
				'def'		=> '#333333',
                'extra_modes' => array('alpha', 'linear-gradient', 'radial-gradient'),
                'note'		=> esc_html__("NB: using gradients you will automatically exclude patterns", 'lc-lightbox-lite'),
			),
			'lcll_lb_ol_pattern' => array(
				'type'		=> 'custom',
				'callback'	=> 'lcll_lb_ol_pattern_f',
				'validation'=> array(
					array('index' => 'lcll_lb_ol_pattern', 'label' => 'Lb overlay pattern'),
				),
			), 
			'lcll_lb_max_w' => array(
				'label' 	=> esc_html__('Maximum width', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 20,
				'max_val'	=> 100,	
				'step'		=> 1,
				'def'		=> 85,
				'value'		=> '%',
                'respect_limits' => true,
				'note'		=> esc_html__("Set the lightbox maximum width, in relation to browser's one", 'lc-lightbox-lite'),
			), 
			'lcll_lb_max_h' => array(
				'label' 	=> esc_html__('Maximum height', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 20,
				'max_val'	=> 100,	
				'step'		=> 1,
				'def'		=> 85,
				'value'		=> '%',
                'respect_limits' => true,
				'note'		=> esc_html__("Set the lightbox maximum height, in relation to browser's one", 'lc-lightbox-lite'),
			), 
			'lcll_lb_padding' => array(
				'label' 	=> esc_html__('Contents padding', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 0,
				'max_val'	=> 20,	
				'step'		=> 1,
				'def'		=> 0,
				'value'		=> 'px',
                'respect_limits' => false,
			), 
			'lcll_lb_border_w' => array(
				'label' 	=> esc_html__('Border width', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 0,
				'max_val'	=> 20,	
				'step'		=> 1,
				'def'		=> 2,
				'value'		=> 'px',
                'respect_limits' => false,
			), 
			'lcll_lb_border_col' => array(
				'label' 	=> esc_html__("Border color", 'lc-lightbox-lite'),
				'type'		=> 'color',
				'def'		=> '#888888',
                'extra_modes' => array('alpha'),
			), 
			'lcll_lb_radius' => array(
				'label' 	=> esc_html__('Border radius', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 0,
				'max_val'	=> 25,	
				'step'		=> 1,
				'def'		=> 2,
				'value'		=> 'px',
                'respect_limits' => false,
			),
			'lcll_lb_use_shadow' => array(
				'label' => esc_html__('Outer shadow?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
			), 
			'lcll_lb_txt_pos' => array(
				'label' 	=> esc_html__("Text position", 'lc-lightbox-lite'),
				'type'		=> 'select',
				'val' 		=> array(
					'under'	=> esc_html__('Under image', 'lc-lightbox-lite'),
					'over'	=> esc_html__('Over image', 'lc-lightbox-lite'), 
					'rside'	=> esc_html__('On right side', 'lc-lightbox-lite'),
					'lside'	=> esc_html__('On left side', 'lc-lightbox-lite'), 
				),
			),
            'lcll_lb_side_txt_w' => array(
				'label' 	=> esc_html__('Side text width', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 100,
				'max_val'	=> 800,	
				'step'		=> 10,
				'def'		=> 330,
				'value'		=> 'px',
                'respect_limits' => false,
				'note'		=> esc_html__("Defining the side bar width when lightbox text is placed on sides", 'lc-lightbox-lite'),
			),
			'lcll_lb_txt_threshold' => array(
				'label' 	=> esc_html__('Text visibility threshold', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 200,
				'max_val'	=> 3500,	
				'step'		=> 100,
				'def'		=> 600,
				'value'		=> 'px',
                'respect_limits' => false,
				'note'		=> esc_html__("Screens smaller than this value have text hidden by default", 'lc-lightbox-lite'),
			),
			'lcll_lb_cmd_pos' => array(
				'label' 	=> esc_html__("Commands position", 'lc-lightbox-lite'),
				'type'		=> 'select',
				'val' 		=> array(
					'inner'	=> esc_html__('Inner', 'lc-lightbox-lite'),
					'outer'	=> esc_html__('Outer', 'lc-lightbox-lite'), 
				),
			),
			'lcll_lb_corner_close' => array(
				'label' => esc_html__('Closing button in corner position?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
                'note'		=> esc_html__("Used only when commands are set on the inner position", 'lc-lightbox-lite'),
			), 
			'lcll_lb_middle_nav_pos' => array(
				'label' => esc_html__('Navigation buttons in middle position?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
			), 
			
            'spcr1' => array(
				'type' => 'spacer',
			),  
            
			'lcll_lb_thumbs' => array(
				'label' => esc_html__('Use thumbnails navigation?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
			),
			'lcll_lb_tn_threshold' => array(
				'label' 	=> esc_html__('Thumbnails visibility threshold', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 200,
				'max_val'	=> 2500,	
				'step'		=> 100,
				'def'		=> 600,
				'value'		=> 'px',
                'respect_limits' => false,
				'note'		=> esc_html__("Screens smaller than this value have thumbnails hidden by default", 'lc-lightbox-lite'),
			),
			'lcll_lb_thumb_sizes' => array(
				'label' 	=> esc_html__("Thumbnail sizes", 'lc-lightbox-lite'),
                'type'		=> '2_numbers',
				'min_val'	=> 10,
				'max_val'	=> 300,	
				'value'		=> 'px',
				'def'		=> array(100, 100),
                'note'		=> esc_html__('Set lightbox thumbnail sizes (width x height)', 'lc-lightbox-lite'),
			),
			'lcll_lb_fullscreen' => array(
				'label' => esc_html__('Enable fullscreen mode?', 'lc-lightbox-lite'),
				'type'		=> 'select',
				'val' 		=> array(
					'0'    => esc_html__('No', 'lc-lightbox-lite'),
					'1'    => esc_html__('Yes - do not force browser fullscreen mode', 'lc-lightbox-lite'),
					'2'    => esc_html__('Yes - force browser fullscreen mode', 'lc-lightbox-lite'), 
				),
				'note'	=> esc_html__("If checked, allows to view image on fullscreen", 'lc-lightbox-lite'),      
			),
            'lcll_lb_no_touchswipe' => array(
				'label' => esc_html__('Disable touch interactions?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, disables touch interactions on mobile devices. Should be checked only in specific incompatibility cases", 'lc-lightbox-lite'),
			),
			'lcll_lb_fs_treshold' => array(
				'label' 	=> esc_html__('Fullscreen threshold', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 200,
				'max_val'	=> 2500,	
				'step'		=> 100,
				'def'		=> 600,
				'value'		=> 'px',
                'respect_limits' => false,
				'note'		=> esc_html__("Lightbox will be only in fullscreen mode for screens smaller than this value", 'lc-lightbox-lite'),
			),
			'lcll_lb_download' => array(
				'label' => esc_html__('Download button?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, enables images download button (only for self hosted images)", 'lc-lightbox-lite'),
			),
			'lcll_lb_counter' => array(
				'label' => esc_html__('Show images counter?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, displays images count and progress", 'lc-lightbox-lite'),
			),
			'lcll_lb_socials' => array(
				'label' => esc_html__('Enable socials?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, enables social share", 'lc-lightbox-lite'),
			),
            'lcll_lb_disable_rclick' => array(
				'label' => esc_html__("Disable right click?", 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, disables right click on lightbox images", 'lc-lightbox-lite'),
			), 
				
            'spcr2' => array(
				'type' => 'spacer',
			),  
            
			'lcll_lb_slideshow' => array(
				'label' => esc_html__('Auto start slideshow?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, starts slideshow on lightbox opening", 'lc-lightbox-lite'),
			),
			'lcll_lb_progressbar' => array(
				'label' => esc_html__('Show progressbar?', 'lc-lightbox-lite'),
				'type'	=> 'checkbox',
				'note'	=> esc_html__("If checked, shows a progressbar during slideshow", 'lc-lightbox-lite'),
			),
			'lcll_lb_oc_time' => array(
				'label' 	=> esc_html__('Open / Close timing', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 0,
				'max_val'	=> 2000,	
				'step'		=> 50,
				'def'		=> 400,
				'value'		=> 'ms',
                'respect_limits' => false,
				'note'		=> esc_html__("Set open/close lightbox timing (in milliseconds - default: 500)", 'lc-lightbox-lite'),
			),
			'lcll_lb_time' => array(
				'label' 	=> esc_html__('Sliding animation timing', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 0,
				'max_val'	=> 2000,	
				'step'		=> 50,
				'def'		=> 400,
				'value'		=> 'ms',
                'respect_limits' => false,
				'note'		=> esc_html__("Set minimum time to switch from an image to another (in milliseconds - default: 400)", 'lc-lightbox-lite'),
			),
			'lcll_lb_ss_time' => array(
				'label' 	=> esc_html__('Slideshow interval', 'lc-lightbox-lite'),
				'type'		=> 'slider',
				'min_val'	=> 2000,
				'max_val'	=> 15000,	
				'step'		=> 200,
				'def'		=> 5000,
				'value'		=> 'ms',
                'respect_limits' => false,
				'note'		=> esc_html__("Set slideshow interval's time in milliseconds (default 5000)", 'lc-lightbox-lite'),
			),
		), 
	),	
);



// ENJOYING THE PLUGIN?
$structure['want_more'] = array(
	'want_more_adv_sect' => array(
		'sect_name'	=> false,
		'fields' 	=> array(
			
            'want_more_adv' => array(
				'type'		=> 'custom',
				'callback'	=> 'lcll_want_more_adv_cb',
			),
        ),
    ),
);



// GG-FILTER - manipulate settings structure
$GLOBALS['lcll_settings_structure'] = apply_filters('lcll_settings_structure', $structure);
