<?php 
if(!defined('ABSPATH')) {exit;}


////////////////////////////////////////////////////////
// Lightbox overlay pattern
function lcll_lb_ol_pattern_f($field_id, $field, $value, $all_vals) {
	$no_pattern_sel = (!$value || $value == 'none') ? 'lcll_pattern_sel' : '';
	
	echo '
	<tr class="lcll_'. esc_attr($field_id) .'">
		<td class="lcwp_sf_label"><label>'. esc_html__("Background pattern", 'lc-lightbox-lite') .'</label></td>
		<td class="lcwp_sf_field" colspan="2">
			<input type="hidden" value="'. esc_attr($value) .'" name="lcll_lb_ol_pattern" id="lcll_lb_ol_pattern" />
			
			<div class="lcll_setting_pattern '. esc_attr($no_pattern_sel) .'" rel="none"> '. esc_html__("no pattern", 'lc-lightbox-lite') .' </div>';
			
			foreach(lcll_patterns_list() as $pattern) {
				$sel = ($value == $pattern) ? 'lcll_pattern_sel' : '';  
                
				echo '<div class="lcll_setting_pattern '. esc_attr($sel) .'" rel="'. esc_attr($pattern) .'" style="background: url('. esc_attr(LCLL_URL) .'/js/lc-lightbox/img/patterns/'. esc_attr($pattern) .'.png) repeat top left transparent;"></div>';		
			}
	
	echo '
		</td>
	</tr>';
	
    
    $inline_js = '
    (function($) { 
        "use strict"; 
        
		$(document).on("click", ".lcll_setting_pattern", function() { // select a pattern
			$(".lcll_setting_pattern").removeClass("lcll_pattern_sel");
			$(this).addClass("lcll_pattern_sel"); 
			
			$("#lcll_lb_ol_pattern").val( $(this).attr("rel") );
		});
	})(jQuery);';
    wp_add_inline_script('lc-select', $inline_js);
}





// donate if like
function lcll_want_more_adv_cb($field_id, $field, $value, $all_vals) {
    $link = 'https://lcweb.it/global-gallery-wordpress-photogallery-plugin/?utm_source=lcll';
    $trial_link = 'https://lcweb.dikelicensing.com/trial-license-request/?prod=gg';
    ?>
    <table id="lcll_want_more_wrap" class="widefat">
        <tbody>
            <tr>
                <td>
                    <div id="lcll_wmw">

                        <div id="lcll_wmw_main">
                            <div>
                                <h3><?php esc_html_e('This is just the beginning!', 'lc-lightbox-lite') ?></h3>
                                <h4><p><?php
                                    // translators: 1: opening <strong><a> tag linking to Global Gallery, 2: closing </a></strong> tag.
                                    echo sprintf(esc_html__('LC Lightbox functionalities are taken from from %1$sGlobal Gallery%2$s, the most complete and refined photogallery plugin you can have today on WordPress', 'lc-lightbox-lite'),
                                        '<strong><a href="'. esc_url($link) .'" target="_blank">',
                                        '</a></strong>',
                                    )
                                ?>
                                </p></h4>

                                <div>
                                    <a href="<?php echo esc_attr($link) ?>" class="button button-primary"><?php esc_html_e('Check it out', 'lc-lightbox-lite') ?></a>
                                    <a href="<?php echo esc_attr($trial_link) ?>" class="button button-secondary"><?php esc_html_e('7-days free trial', 'lc-lightbox-lite') ?></a>
                                </div>

                                <div>
                                    <span><i class="dashicons dashicons-shield"></i> <?php esc_html_e('Trusted by 5500+ premium websites', 'lc-lightbox-lite') ?></span>
                                    <span><i class="dashicons dashicons-update"></i> <?php esc_html_e('14-days refund guarantee', 'lc-lightbox-lite') ?></span>
                                </div>
                            </div>
                            <img src="<?php echo esc_attr(LCLL_URL) ?>/img/gg_adv_logo.png" alt="<?php esc_attr_e('Global Gallery', 'lc-lightbox-lite') ?>" />
                        </div>


                        <div id="lcll_wmw_features">
                            <h3><?php esc_html_e('Everything you need and more', 'lc-lightbox-lite') ?></h3> 
                            <h4><p><?php esc_html_e('Global Gallery is designed to fit any website and offering the richest features list available today', 'lc-lightbox-lite') ?></p></h4>

                            <ul>
                                <li><?php esc_html_e('Unlimited photogalleries. Each one capable of storing thousands of images', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('4 gallery layouts: Standard (fixed images sizes), columnized, masonry and photostring (justified)', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Gallery image tags filter and search', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Image-to-Gallery system featuring 6 different layouts and multipe customizations', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Images slider with fixed/responsive sizing, zoom-on-hover and lightbox support', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Images carousel with multi-column and image-centric mode + lightbox support', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Visual gallery builder with drag&drop sorting and thumbnails cropping management', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Automatic gallery population with automatic cache update', 'lc-lightbox-lite') ?></li>
                                <li><?php
                                    // translators: 1: opening <em> tag, 2: closing </em> tag.
                                    echo sprintf(esc_html__('Automatic gallery images sorting by title, author and date ( %1$sNB: by date only for WP sources%2$s)', 'lc-lightbox-lite'),
                                        '<em>',
                                        '</em>'
                                    )
                                ?></li>
                                <li><?php esc_html_e('SEO deeplink engine for gallery and collection systems', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Self-hosted images sitemap', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Self-hosted images management system: direct folders creation and files upload with IPTC meta data read/update', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Unlimited image sources', 'lc-lightbox-lite') ?> <ul>
                                    <li><?php esc_html_e('Wordpress image library', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Wordpress categories or custom post types (associated to a taxonomy)', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Dropbox', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Amazon AWS S3', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Flickr sets, photostreams and tags', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Pinterest boards', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Google Drive', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('nextGEN gallery plugin galleries', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Tumblr blogs', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('Self-hosted images', 'lc-lightbox-lite') ?></li>
                                    <li><?php esc_html_e('ANY RSS feed (therefore also Facebook and Instagram via Zapier)', 'lc-lightbox-lite') ?></li>
                                    </ul>
                                </li>
                                <li><?php esc_html_e('Wordpress gallery integration (use WP engine to setup galleries, sliders, carousels and image-to-gallery)', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('7 lightboxes ready out of the box. Each one with specific customizations', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Gallery Collections with filtering system', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Overlay image effects wizard (grayscale, blur, sepia, saturation, contrast, etc)', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Image watermarking system', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Optional lightbox images optimization (downscale + WEBP/AVIF)', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Optional thumbnails WEBP/AVIF optimization (through Easy WP Thumbs)', 'lc-lightbox-lite') ?></li>
                                <li><?php
                                    // translators: 1: opening <a> tag linking to Elementor, 2: closing </a> tag.
                                    echo sprintf(esc_html__('Natively integrated in %1$sElementor%2$s, Divi Builder (4 & 5) and WPBakery Page Builder', 'lc-lightbox-lite'),
                                        '<a href="https://trk.elementor.com/1930">',
                                        '</a>'
                                    )
                                ?></li>
                                <li><?php esc_html_e('Full image sizes, colors, margins, borders control', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('1-click immediate setup with 8 preset styles', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Advanced gallery cache, optimizing resources usage and loading speed', 'lc-lightbox-lite') ?></li>
                                <li><?php esc_html_e('Images "right-click" protection', 'lc-lightbox-lite') ?></li>
                            </ul>
                        </div>

                        <div id="lcll_wmw_footer">
                            <img src="<?php echo esc_attr(LCLL_URL) ?>'/img/gg_logo.svg'" alt="<?php esc_attr_e('Global Gallery', 'lc-lightbox-lite') ?>">

                            <div>
                                <h3><?php esc_html_e('Choose the best for your images', 'lc-lightbox-lite') ?></h3>
                                <p><?php esc_html_e('Join thosands of customers and upgrade to a premium experience', 'lc-lightbox-lite') ?></p>
                            </div>

                            <span>
                                <a href="<?php echo esc_attr($link) ?>" class="button button-primary"><?php esc_html_e('Check it out', 'lc-lightbox-lite') ?></a>
                                <a href="<?php echo esc_attr($trial_link) ?>" class="button button-secondary"><?php esc_html_e('7-days free trial', 'lc-lightbox-lite') ?></a>
                            </span>
                        </div>
                    </div>    
                </td>
            </tr> 	
        </tbody>
    </table>
    <?php
}