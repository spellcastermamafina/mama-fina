<?php 
if(!defined('ABSPATH')) {exit;}


// framework engine
include_once(LCLL_DIR .'/classes/simple_form_validator.php');
include_once(LCLL_DIR .'/settings/settings_engine.php'); 
include_once(LCLL_DIR .'/settings/field_options.php'); 
include_once(LCLL_DIR .'/settings/custom_fields.php');
include_once(LCLL_DIR .'/settings/structure.php'); 



lcll_settings_engine::$prod_acronym = 'lcll';
lcll_settings_engine::$css_prefix = 'lcll_';

$engine = new lcll_settings_engine('lcll_settings', $GLOBALS['lcll_settings_tabs'], $GLOBALS['lcll_settings_structure']);
?>

<div class="wrap lcwp_settings_wrap"> 
    <div class="lcwp_settings_head">
        <h2><?php esc_html_e('LC Lightbox Lite Settings', 'lc-lightbox-lite') ?></h2>  
        
        <div>
            <?php echo lcll_settings_engine::wp_kses_ext($engine->import_export_btns()) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <form class="lcwp_sf_search_wrap">
                <i class="dashicons dashicons-no-alt"></i>
                <input type="text" name="lcwp_sf_search" value="" placeholder="<?php esc_attr_e('search fields', 'lc-lightbox-lite') ?> .." /> 
            </form>
        </div>
    </div>
    
	<?php
    // get fetched data and allow customizations
    if($engine->form_submitted()) {
        $fdata = $engine->form_data;
        $errors = (!empty($engine->errors)) ? $engine->errors : array();


        // LCLL-FILTER - manipulate setting errors - passes errors array and form values - error subject as index + error text as val
        $errors = apply_filters('lcll_setting_errors', $errors, $fdata);	
        
        
        // save or print error
        if(empty($errors)) {
            
            // LCLL-FILTER - allow data manipulation (or custom actions) before settings save - passes form values
            $engine->form_data = apply_filters('lcll_before_save_settings', $fdata); 
            
            // save
            $engine->save_data();

            if(!isset($noredirect)) {
			     $engine->successful_save_redirect();
            }
        }
        
        // compose and return errors
        else {
            echo lcll_settings_engine::wp_kses_ext($engine->get_error_message_html($errors)); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
	
	
	// if successfully saved
	echo lcll_settings_engine::wp_kses_ext($engine->get_success_message_html()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	
	// print form code
    echo lcll_settings_engine::wp_kses_ext($engine->get_code()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    ?>
</div>


<?php
// LCLL-ACTION - allow extra code printing in settings (for javascript/css)
do_action('lcll_settings_extra_code');
?>
