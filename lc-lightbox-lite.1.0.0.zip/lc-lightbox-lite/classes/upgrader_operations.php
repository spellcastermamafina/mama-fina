<?php
// wrapping up operations to be done on plugin's update/activation
if(!defined('ABSPATH')) {exit;}

class lcll_upgrader_operations {
    public static function run() {
        foreach(get_class_methods(__CLASS__) as $method) {
            if($method == 'run') {
                continue;   
            }
            call_user_func(array(__CLASS__, $method));
        }
    }
    ////////////////////////////////////////////////////////////////////////
    
    

}
