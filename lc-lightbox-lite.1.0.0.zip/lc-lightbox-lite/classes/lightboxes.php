<?php
if(!defined('ABSPATH')) {exit;}

class lcll_lightboxes {
    
    
    /* returns the overall dynamic JS code  related to GG lightbox */
    public static function get_dynamic_js_code() {
        $code = self::throw_lb_code();
        
        return str_replace(
            array("\r", "\n", "\t", "\v"), 
            '', 
            $code
        );
    }
    
    
    
    
    /* enqueues the CSS/JS scripts */
    public static function enqueue_scripts() {
        $code = '(function($) {"use strict";'. self::get_dynamic_js_code() .'})(jQuery);';
        wp_add_inline_script('jquery', $code);
    }
    
    
    
    
    /* returns the throw lightbox JS code  */
    private static function throw_lb_code() {
        $code = '
        let lcll_prepare,
            lcll_nulling_prepare, 
            lcll_ptb_executed;';


        // GG LC lightbox options available for everyone
        if(function_exists('get_options')) {
            $opts = get_options(array(
                'lcll_lb_openclose',
                'lcll_lb_oc_time',
                'lcll_lb_time',
                'lcll_lb_ss_time',
                'lcll_lb_slideshow',
                'lcll_lb_counter',
                'lcll_lb_progressbar',
                'lcll_lb_max_w',
                'lcll_lb_max_h',
                'lcll_lb_ol_color',
                'lcll_lb_ol_pattern',
                'lcll_lb_side_txt_w',
                'lcll_lb_border_w',
                'lcll_lb_border_col',
                'lcll_lb_padding',
                'lcll_lb_radius',
                'lcll_lb_use_shadow',
                'lcll_lb_style',
                'lcll_lb_txt_pos',
                'lcll_lb_cmd_pos',
                'lcll_lb_corner_close',
                'lcll_lb_middle_nav_pos',
                'lcll_lb_txt_threshold',
                'lcll_lb_thumbs',
                'lcll_lb_tn_threshold',
                'lcll_lb_thumb_sizes',
                'lcll_lb_fullscreen',
                'lcll_lb_fs_treshold',
                'lcll_lb_socials',
                'lcll_lb_download',
                'lcll_lb_no_touchswipe',
                'lcll_lb_disable_rclick',
            ));
        }


        $thumb_sizes = array_map('absint', (array)get_option('lcll_lb_thumb_sizes', array(100, 80)));
        if(count($thumb_sizes) < 2) {
            $thumb_sizes = array(100, 80);   
        }

        $code .= "
        window.lcll_config = {
            global_type     : 'image',
            wrap_class      : '" . esc_js(get_option('lcll_lb_openclose', 'lcl_zoomin_oc')) . "',
            author_by_txt   : `" . esc_html__('by', 'lc-lightbox-lite') . "`,
            slideshow       : true,
            open_close_time : " . absint(get_option('lcll_lb_oc_time', 500)) . ",
            animation_time  : " . absint(get_option('lcll_lb_time', 500)) . ",
            slideshow_time  : " . absint(get_option('lcll_lb_ss_time', 5000)) . ",
            autoplay        : " . ((!get_option('lcll_lb_slideshow')) ? 'false' : 'true') . ",
            counter         : " . ((get_option('lcll_lb_counter')) ? 'true' : 'false') . ",
            progressbar     : " . ((get_option('lcll_lb_progressbar')) ? 'true' : 'false') . ",
            max_width       : '" . absint(get_option('lcll_lb_max_w', 85)) . "%',
            max_height      : '" . absint(get_option('lcll_lb_max_h', 85)) . "%',
            ol_color        : '" . esc_js(get_option('lcll_lb_ol_color', '#333333')) . "',
            ol_pattern      : " . ((get_option('lcll_lb_ol_pattern', 'none') == 'none') ? 'false' : "'" . str_replace('pattern-', '', esc_html(get_option('lcll_lb_ol_pattern'))) . "'") . ",
            side_txt_w      : ". absint(get_option('lcll_lb_side_txt_w', 330)) .",
            border_w        : " . absint(get_option('lcll_lb_border_w', 2)) . ",
            border_col      : '" . esc_js(get_option('lcll_lb_border_col', '#888888')) . "',
            padding         : " . absint(get_option('lcll_lb_padding', 0)) . ",
            radius          : " . absint(get_option('lcll_lb_radius', 2)) . ",
            shadow          : " . ((get_option('lcll_lb_use_shadow')) ? 'true' : 'false') . ",
            remove_scrollbar: true,
            skin            : '" . esc_js(get_option('lcll_lb_style', 'minimal')) . "',
            data_position   : '" . esc_js(get_option('lcll_lb_txt_pos', 'under')) . "',
            cmd_position    : '" . esc_js(get_option('lcll_lb_cmd_pos', 'inner')) . "',
            ins_close_pos   : '" . ((get_option('lcll_lb_corner_close')) ? 'corner' : 'normal') . "',
            nav_btn_pos     : '" . ((get_option('lcll_lb_middle_nav_pos')) ? 'middle' : 'normal') . "',
            txt_hidden      : " . absint(get_option('lcll_lb_txt_threshold', 600)) . ",
            thumbs_nav      : " . ((!get_option('lcll_lb_thumbs')) ? 'false' : 'true') . ",
            tn_hidden       : " . absint(get_option('lcll_lb_tn_threshold', 600)) . ",
            thumbs_w        : " . $thumb_sizes[0] . ",
            thumbs_h        : " . $thumb_sizes[1] . ",
            thumbs_maker_url: false,
            fullscreen      : " . ((absint(get_option('lcll_lb_fullscreen'))) ? 'true' : 'false') . ",
            browser_fs_mode : ". ((absint(get_option('lcll_lb_fullscreen')) === 2) ? 'true' : 'false') . ",
            fs_only         : " . absint(get_option('lcll_lb_fs_treshold', 600)) . ",
            socials         : " . ((!get_option('lcll_lb_socials')) ? 'false' : 'true') . ",
            download        : " . ((!get_option('lcll_lb_download')) ? 'false' : 'true') . ",
            touchswipe      : " . ((get_option('lcll_lb_no_touchswipe')) ? 'false' : 'true') . ",
            rclick_prevent  : " . ((get_option('lcll_lb_disable_rclick')) ? 'true' : 'false') . ",";

            if(get_option('lcll_lb_download')) {
                $code .= "
                html_is_ready : function(e, vars) {

                    if(typeof(vars) != 'undefined') {
                        jQuery.each(vars.elems, function(i,v) {
                            v.download = v.src;
                        });
                    }
                }";
            }

        $code .= "
        };";

                
        
        return $code;
    }
    
}